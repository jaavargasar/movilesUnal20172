================================
ColorPickerPreference Change Log
================================

2011-02-11 v1.11:
----------------
fix: color controls not visible in landscape orientation
fix: colorPickerDialog constructor was protected

2011-01-25 v1.1:
----------------
* new: Alpha Slider is disabled by default
* new: Alpha Slider can be enabled:
    * with preference XML using attribute alphaSlider="true"
    * with function setAlphaSliderEnabled(true)
* new: defaultValue in preference XML now accepts HEX color code:
    * #FF00FF, rgb
    * #FF00FF00, argb

2011-01-20 v1.01:
-----------------
fix: sometimes preview color disappear

2011-01-19 v1.0:
----------------
release