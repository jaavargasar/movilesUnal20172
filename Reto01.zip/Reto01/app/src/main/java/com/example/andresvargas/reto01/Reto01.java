package com.example.andresvargas.reto01;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class Reto01 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reto01);
    }
}
